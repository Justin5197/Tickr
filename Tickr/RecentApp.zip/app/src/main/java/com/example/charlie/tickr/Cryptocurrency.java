package com.example.charlie.tickr;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Cryptocurrency extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cryptocurrency);
    }
}
