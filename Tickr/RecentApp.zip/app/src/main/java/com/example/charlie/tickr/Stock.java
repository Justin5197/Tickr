package com.example.charlie.tickr;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Stock extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock);

        final TextView SP = (TextView) findViewById(R.id.StockPrice);
        Button StockPrice = (Button) findViewById(R.id.FindStock);
        StockPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Stocks s = new Stocks("MSFT");
                try {
                    //System.out.printf(s.returnAPIresponse("hello"));
                    double re = s.getStockPrice("MSFT");
                    String price = "";
                    if (re > 0.0) {
                        price = re + "";
                        SP.setText(price);
                    } else {
                        price = "INVALID API REQUEST CALL";
                    }

                    Log.d("OutPutTestingTag",price);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}


